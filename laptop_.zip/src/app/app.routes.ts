import { Routes } from '@angular/router';
import { LoaiListComponent } from './components/loai-list/loai-list.component';
import { LoaiFormComponent } from './components/loai-form/loai-form.component';
import { SanPhamListComponent } from './components/san-pham-list/san-pham-list.component';
import { SanPhamFormComponent } from './components/san-pham-form/san-pham-form.component';
import { HomeComponent } from './home/home.component';
import { DangKyComponent } from './dang-ky/dang-ky.component';
import { DangNhapComponent } from './dang-nhap/dang-nhap.component';
export const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'dang-ky', component: DangKyComponent, title: 'Đăng Ký' },
    { path: 'dang-nhap', component: DangNhapComponent, title: 'Đăng Nhập' },
    { path: 'admin/loai', component: LoaiListComponent },
    { path: 'admin/loai/them', component: LoaiFormComponent },
    { path: 'admin/loai/sua/:id', component: LoaiFormComponent },
    { path: 'admin/sp', component: SanPhamListComponent },
    { path: 'admin/sp/them', component: SanPhamFormComponent },
    { path: 'admin/sp/sua/:id', component: SanPhamFormComponent }
];
