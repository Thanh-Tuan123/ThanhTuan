export class Loai {
    id!: number;
    ten_loai!: string;
    thu_tu: number = 0;
    an_hien: boolean = true;
}
