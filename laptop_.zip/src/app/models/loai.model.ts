
import { Loai } from './loai';  

export interface LoaiResponse {
  status: string;
  data: Loai;
}
