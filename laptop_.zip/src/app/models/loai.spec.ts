import { Loai } from './loai';

describe('Loai', () => {
  it('should create an instance', () => {
    expect(new Loai()).toBeTruthy();
  });
});
