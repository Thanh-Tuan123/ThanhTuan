export class san_pham {
  id!: number;
  ten_sp!: string;
  gia: number = 0;
  hinh?: string;
  id_loai!: number;
  ten_loai!: string;
  slug?: string;
  ngay: string = new Date().toISOString().split('T')[0];
  an_hien: boolean = true;
  hot: boolean = false;
  luot_xem: number = 0;
}