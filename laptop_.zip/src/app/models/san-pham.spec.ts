import { SanPham } from './san-pham';

describe('SanPham', () => {
  it('should create an instance', () => {
    expect(new SanPham()).toBeTruthy();
  });
});
