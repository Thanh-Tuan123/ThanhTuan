import { Component, OnInit } from '@angular/core';
import { SanPhamService } from '../../services/san-pham.service';
import { san_pham } from '../../models/san-pham';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-san-pham-form',
  imports: [CommonModule, FormsModule],
  templateUrl: './san-pham-form.component.html',
})
export class SanPhamFormComponent implements OnInit {
  sp: san_pham = new san_pham();
  loai_arr: { id: number; ten_loai: string }[] = [];
  selectedFile?: File;
  previewImage: string = '';

  constructor(
    private spServie: SanPhamService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Lấy danh sách loại từ API
    this.spServie.getLoai().subscribe((loaiData) => {
      if (loaiData && Array.isArray(loaiData.data)) {
        this.loai_arr = loaiData.data;
      } else {
        console.error('Lỗi: Dữ liệu loại không hợp lệ:', loaiData);
        this.loai_arr = []; // tránh lỗi ngFor
      }

      // Nếu có id => load sản phẩm để sửa
      const id = this.route.snapshot.params['id'];
      if (id) {
        this.spServie.getOne(id).subscribe((data) => {
          this.sp = data;
          this.sp.id_loai = Number(data.id_loai); // ép kiểu để binding đúng
          if (data.hinh) this.previewImage = `${data.hinh}`;
        });
      }
    });
  }

  onSubmit() {
    if (this.selectedFile) {
      const formData = new FormData();
      formData.append('file', this.selectedFile);
      this.spServie.uploadFile(formData).subscribe((response) => {
        this.sp.hinh = response.filename;
        this.submitSP();
      });
    } else {
      this.submitSP();
    }
  }

  submitSP() {
    if (this.sp.id) {
      this.spServie.update(this.sp.id, this.sp).subscribe(() => {
        this.router.navigate(['/admin/sp']);
      });
    } else {
      this.spServie.create(this.sp).subscribe(() => {
        this.router.navigate(['/admin/sp']);
      });
    }
  }

  onFileSelected(event: any) {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      this.selectedFile = fileInput.files[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.previewImage = e.target.result;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }
}
