import { Component, OnInit } from '@angular/core';
import { LoaiService } from '../../services/loai.service';
import { Loai } from '../../models/loai';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-loai-list',
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './loai-list.component.html'
})
export class LoaiListComponent implements OnInit {
  loai_arr: Loai[] = [];
  searchTerm: string = "";

  constructor(private loaiService: LoaiService) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.loaiService.getAll().subscribe(response => {
      if (response && response.data && Array.isArray(response.data)) {
        this.loai_arr = response.data;
      } else {
        console.error('Dữ liệu không hợp lệ hoặc không có trường "data"', response);
      }
    });
  }

  xoa(id: number) {
    if (confirm('Bạn có chắc chắn muốn xóa không?') == false) return;
    this.loaiService.delete(id).subscribe(() => this.loadData());
  }

  getLoai() {
    if (this.searchTerm.trim().length >= 2) {
      this.loaiService.getAll().subscribe(res => {
        console.log('Kết quả API:', res);
        
        if (res && Array.isArray(res.data)) {
          const keyword = this.searchTerm.trim().toLowerCase();
          this.loai_arr = res.data.filter((item: any) =>
            item.ten_loai?.toLowerCase().includes(keyword)
          );
        } else {
          console.error('Dữ liệu trả về không hợp lệ:', res);
          this.loai_arr = [];
        }
      });
    } else {
      this.loadData();
    }
  }
}
