import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoaiListComponent } from './loai-list.component';

describe('LoaiListComponent', () => {
  let component: LoaiListComponent;
  let fixture: ComponentFixture<LoaiListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoaiListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoaiListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
