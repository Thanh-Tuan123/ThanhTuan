import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaiService } from '../../services/loai.service';
import { Loai } from '../../models/loai';
import { LoaiResponse } from '../../models/loai.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-loai-form',
  imports: [FormsModule, CommonModule],
  templateUrl: './loai-form.component.html'
})
export class LoaiFormComponent {
  loai: Loai = new Loai();
  isEdit: boolean = false;

  constructor(
    private loaiservice: LoaiService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    console.log('ID from URL:', id);  // Log ID từ URL
    if (id) {
      this.isEdit = true;
      this.loaiservice.getOne(+id).subscribe((response: LoaiResponse) => {
        console.log('Response received:', response);  // Log dữ liệu API
        if (response && response.data) {
          // Đảm bảo response.data là đối tượng đúng kiểu Loai
          const loaiData: Loai = {
            id: response.data.id,
            ten_loai: response.data.ten_loai,
            thu_tu: response.data.thu_tu,
            // Nếu response.data.an_hien là kiểu boolean, gán trực tiếp
            an_hien: response.data.an_hien  // Không cần phải so sánh
          };
          this.loai = loaiData;
          console.log('Loai data after API response:', this.loai);  // Log dữ liệu sau khi gán
        } else {
          console.error('Response does not contain valid data:', response);
        }
      }, error => {
        console.error('Error fetching data:', error);
      });
    } else {
      this.isEdit = false;
    }
  }
  onSubmit() {
    console.log('Loai onSubmit:', this.loai);  // Log giá trị loai khi submit

    if (this.isEdit) {
      if (!this.loai.id) {
        console.error('ID is undefined or invalid for update');
        return;
      }
      console.log('Updating Loai with ID:', this.loai.id);  // Log ID trước khi cập nhật
      this.loaiservice.update(this.loai.id, this.loai).subscribe(() => {
        this.router.navigate(['/admin/loai']);
      });
    } else {
      console.log('Creating new Loai'); // Log khi tạo mới
      this.loaiservice.create(this.loai).subscribe(() => {
        this.router.navigate(['/admin/loai']);
      });
    }
  }
}
