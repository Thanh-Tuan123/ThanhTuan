import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoaiFormComponent } from './loai-form.component';

describe('LoaiFormComponent', () => {
  let component: LoaiFormComponent;
  let fixture: ComponentFixture<LoaiFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoaiFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoaiFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
