import { Component, OnInit } from '@angular/core';
import { SanPhamService } from '../../services/san-pham.service';
import { san_pham } from '../../models/san-pham';
import { Loai } from '../../models/loai';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { registerLocaleData } from '@angular/common';
import localeVI from '@angular/common/locales/vi';
registerLocaleData(localeVI);

@Component({
  selector: 'app-san-pham-list',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './san-pham-list.component.html',
})
export class SanPhamListComponent implements OnInit {
  sp_arr: san_pham[] = [];
  searchTerm: string = '';
  loai_arr: Loai[] = [];
  id_loai: string = '-1'; 
  sp_arr_goc: san_pham[] = []; 

  constructor(private spService: SanPhamService) {}

  ngOnInit(): void {
    this.loadSP();
    this.spService.getLoai().subscribe((res) => (this.loai_arr = res.data));
  }

  getImageUrl(hinh: string): string {
    if (!hinh) return '';
    if (hinh.startsWith('http://') || hinh.startsWith('https://')) {
      return hinh;
    }
    return `http://localhost:3000/uploads/${hinh}`;
  }

  loadSP(): void {
    this.spService.getAll().subscribe((data) => {
      this.sp_arr = data;
      this.sp_arr_goc = [...data];
    });
  }

  xoaSP(id: number): void {
    if (confirm('Xóa sản phẩm thật không?')) {
      this.spService.delete(id).subscribe(() => this.loadSP());
    }
  }

  getSanPham() {
    if (this.searchTerm.trim().length >= 2) {
      this.spService.search(this.searchTerm).subscribe((res) => {
        console.log(res.data);
        this.sp_arr = res.data;
      });
    } else {
      this.loadSP();
    }
  }

  locSanPham(): void {
    if (this.id_loai === '-1') {
      this.sp_arr = [...this.sp_arr_goc];
    } else {
      this.sp_arr = this.sp_arr_goc.filter(
        (sp) => sp.id_loai === Number(this.id_loai)
      );
    }
  }
}
