import { Component } from '@angular/core';

@Component({
  selector: 'app-thanhmenu',
  imports: [],
  templateUrl: './thanhmenu.component.html',
  styleUrl: './thanhmenu.component.css'
})
export class ThanhmenuComponent {

}
