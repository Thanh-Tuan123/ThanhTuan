import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dang-nhap',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './dang-nhap.component.html',
  styleUrls: ['./dang-nhap.component.css']
})
export class DangNhapComponent {
  user = { email: "", mat_khau: "" };
  thong_bao: string = "";

  constructor(private router: Router) {}

  async dangnhap() {
    this.thong_bao = ""; // Reset thông báo lỗi trước khi xử lý đăng nhập

    if (!this.user.email.trim()) {
      this.thong_bao = "Vui lòng nhập email.";
      return;
    }
    if (!this.user.mat_khau.trim()) {
      this.thong_bao = "Vui lòng nhập mật khẩu.";
      return;
    }

    try {
      const response = await fetch("http://localhost:3000/api/dangnhap", {
        method: "POST",
        body: JSON.stringify(this.user),
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.thong_bao || "Sai email hoặc mật khẩu.");
      }

      if (data.token) {
        sessionStorage.setItem("user", JSON.stringify(data.info));
        sessionStorage.setItem("token", data.token);
        sessionStorage.setItem("expiresIn", data.expiresIn);

        alert("Đăng nhập thành công!");

        // Điều hướng về trang chủ và tải lại trang
        this.router.navigate(['/']).then(() => {
          window.location.reload();  // Tải lại trang sau khi chuyển hướng
        });
      } else {
        this.thong_bao = "Lỗi xác thực. Vui lòng thử lại!";
      }
    } catch (error: any) {
      console.error("Lỗi đăng nhập:", error);
      this.thong_bao = error.message || "Đăng nhập thất bại.";
    }
  }
}
