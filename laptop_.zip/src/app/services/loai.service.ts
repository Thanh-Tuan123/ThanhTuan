import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Loai } from '../models/loai';
import { LoaiResponse } from '../models/loai.model';

@Injectable({ providedIn: 'root' })
export class LoaiService {
  private apiUrl = 'http://localhost:3000/admin/loai';

  constructor(private http: HttpClient) {}

  // Phương thức trả về kiểu LoaiResponse
  getAll(): Observable<LoaiResponse> {
    return this.http.get<LoaiResponse>(this.apiUrl);
  }

  // loai.service.ts
getOne(id: number): Observable<LoaiResponse> {
  return this.http.get<LoaiResponse>(`${this.apiUrl}/${id}`);
}

  create(loai: Loai): Observable<Loai> {
    return this.http.post<Loai>(this.apiUrl, loai);
  }

  update(id: number, loai: Loai): Observable<Loai> {
    return this.http.put<Loai>(`${this.apiUrl}/${id}`, loai);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
