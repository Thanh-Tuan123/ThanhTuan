import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { san_pham } from '../models/san-pham';
import { Loai } from '../models/loai';

@Injectable({ providedIn: 'root' })
export class SanPhamService {
  private apiUrl = 'http://localhost:3000/admin/sp';

  constructor(private http: HttpClient) { }

  getAll(): Observable<san_pham[]> {
    return this.http.get<san_pham[]>(this.apiUrl);
  }

  getOne(id: number): Observable<san_pham> {
    return this.http.get<san_pham>(`${this.apiUrl}/${id}`);
  }

  create(product: san_pham): Observable<san_pham> {
    return this.http.post<san_pham>(this.apiUrl, product);
  }

  update(id: number, product: san_pham): Observable<san_pham> {
    return this.http.put<san_pham>(`${this.apiUrl}/${id}`, product);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  uploadFile(formData: FormData): Observable<{ filename: string }> {
    return this.http.post<{ filename: string }>(
      'http://localhost:3000/admin/sp/upload',
      formData
    );
  }

  getLoai(): Observable<{ data: Loai[] }> {
    return this.http.get<{ data: Loai[] }>('http://localhost:3000/admin/loai');
  }
  search(key: string) {
    return this.http.get<any>(`http://localhost:3000/admin/sp/search?key=${key}`);
  }
  
}