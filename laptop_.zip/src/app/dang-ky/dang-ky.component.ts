import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dang-ky',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dang-ky.component.html',
  styleUrl: './dang-ky.component.css'
})
export class DangKyComponent {
  user = { email: "", mat_khau: "", go_lai_mat_khau: "", ho_ten: "" };
  errors = { email: "", mat_khau: "", go_lai_mat_khau: "", ho_ten: "" };
  isSubmitting = false; // Trạng thái gửi yêu cầu

  constructor(private router: Router) {}

  validateForm() {
    this.errors = { email: "", mat_khau: "", go_lai_mat_khau: "", ho_ten: "" };

    if (!this.user.email.trim()) {
      this.errors.email = "Vui lòng nhập email.";
    }
    if (!this.user.ho_ten.trim()) {
      this.errors.ho_ten = "Thiếu Họ Tên";
    }
    if (!this.user.mat_khau.trim() || this.user.mat_khau.length < 4) {
      this.errors.mat_khau = "Mật khẩu phải có ít nhất 4 ký tự.";
    }
    if (this.user.mat_khau !== this.user.go_lai_mat_khau) {
      this.errors.go_lai_mat_khau = "Mật khẩu nhập lại không khớp.";
    }

    return Object.values(this.errors).every((err) => err === "");
  }

  async dangky() {
    if (!this.validateForm()) return;

    this.isSubmitting = true; // Bắt đầu gửi yêu cầu

    const opt = {
      method: "POST",
      body: JSON.stringify(this.user),
      headers: { 'Content-Type': 'application/json' }
    };

    try {
      const response = await fetch("http://localhost:3000/api/dangky", opt);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.thong_bao || "Có lỗi xảy ra.");
      }

      alert("Đăng ký thành công! Đang chuyển đến trang đăng nhập...");
      this.router.navigate(['/dang-nhap']); // Chuyển hướng sau khi đăng ký

    } catch (error) {
      alert(error instanceof Error ? `Lỗi đăng ký: ${error.message}` : "Đã xảy ra lỗi không xác định.");
    } finally {
      this.isSubmitting = false; // Hoàn tất xử lý
    }
  }
}
