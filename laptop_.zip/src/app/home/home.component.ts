import { Component } from '@angular/core';
import { LoaiListComponent } from '../components/loai-list/loai-list.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [LoaiListComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {}
