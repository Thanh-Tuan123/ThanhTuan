import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  standalone: true, 
  imports: [CommonModule],
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  ho_ten: string = ""; 

  ngOnInit() {
    if (typeof window !== "undefined") { 
      let user = sessionStorage.getItem("user");
      if (user) {
        this.ho_ten = JSON.parse(user).ho_ten || "";
      }
    }
  }

  dangXuat() {
    if (typeof window !== "undefined") { 
      sessionStorage.removeItem("user");
      sessionStorage.removeItem("token");
      this.ho_ten = "";
      window.location.href = "/dang-nhap";
    }
  }
}
